from flask import Flask, render_template, request, jsonify
import random
from text_classification_predict import TextClassificationPredict
from datetime import date,timedelta
from datetime import datetime

app = Flask(__name__)
GREETING = ["hi", u"chào bạn", u"*gật đầu*", u"Rất vui được nói chuyện với bạn", u"Chào, tôi có thể giúp gì cho bạn không?"]
BYE = ["Goodbye!", "Byeee!"]
BUILDING_LIST = ["A4","B4","C4","B1"]
FLOOR_LIST = ["1","2","3","4","5","6","7","8","9"]
ROOM_LIST = ["101","102","103","104","105","106","107","108","109","201","202","203","204","205","206","207","208","209","301","302","303","304","305","306","307","308","309",
        "401","402","403","404","405","406","407","408","409","501","502","503","504","505","506","507","508","509","601","602","603","604","605","606","607","608","609",
        "701","702","703","704","705","706","707","708","709","801","802","803","804","805","806","807","808","809","901","902","903","904","905","906","907","908","909"]
import time


@app.route("/")
def index():
    return render_template("index.html")  # to send context to html


##############################
flag = 0
building=0
floor = 0
room =  0
day = 0

@app.route("/get",methods=['POST'])
def get_bot_response():
    userText = request.form.get("message")  # get data from input,we write js  to index.html
    # return "BOt:" +str(english_bot.get_response(userText))
    tcp = TextClassificationPredict()
    a = tcp.get_train_data({"feature": userText})
    print(a)
    global flag
    global day
    global building
    global floor
    global room
    error=jsonify({"action":"print", "message":"Sorry, I dont understand!"})
    wrong_input = jsonify({"action": "print", "message": "Sorry, Please Input again!"})
    if flag == 0:
        if a == "chao_hoi":
            print("9999999999999999999999999999")
            c=random.choice(GREETING)
            return jsonify({"action": "print", "message": c})
        elif a == "bye":
            c=random.choice(BYE)
            return jsonify({"action": "print", "message":c})
        elif a == "hoi_thoi_tiet":
            return jsonify({"action":"weather"})
        elif a == "report":
            flag = 1
            return jsonify({"action": "print", "message":"Bạn muốn xem vào tòa nào?"})
        elif a == "kw":
            flag = 2
            return jsonify({"action": "print", "message":"bạn muốn xem khối lượng điện sử dụng khi nào ?"})
        elif a== "user_list":
            return jsonify({"action":"redirected","destination":"user_list"})
        elif a== "profile":
            return jsonify({"action": "redirected", "destination": "profile"})
        elif a == "settings":
            return jsonify({"action":"redirected","destination":"settings"})
        elif a == "dashboard":
            return jsonify({"action": "redirected", "destination": "dashboard"})
        else:
            return error
    elif flag == 1:
        if a == "report_all" and building==0 and floor ==0 and room == 0:
            return jsonify({"action":"redirected","destination":"report"})
        elif a == "building" and building == 0:
            check = text_filer(userText,BUILDING_LIST)
            if check != False:
                building=check
                return jsonify({"action": "print", "message":"Bạn muốn xem tầng nào:"})
            else:
                return wrong_input
        elif a == "floor" and building !=0:
            check = text_filer(userText,FLOOR_LIST)
            if check != False:
                floor=check
                return jsonify({"action": "print", "message": "Bạn muốn xem phòng nào:"})
            else:
                return wrong_input
        if (a == "report_all_floor" or a == "report_all") and building != 0 :
            floor = None
            return jsonify({"action": "print", "message": "Bạn muốn xem thời điểm nào:"})
        if (a == "report_all_room" or a == "report_all") and building!=0 and floor!= 0:
            room = None
            return jsonify({"action": "print", "message": "Bạn muốn xem thời điểm nào:"})
        elif a == "room" and building !=0 and floor != 0:
            check = text_filer(userText, ROOM_LIST)
            if check != False:
                room = check
                return jsonify({"action": "print", "message": "Bạn muốn xem thời điểm nào:"})
            else:
                return wrong_input
        if building != 0 and floor != 0 and room !=0:
            x,y,z=building,floor,room
            flag=0
            building=0
            floor=0
            room=0
            return return_report(x,y,z,a,userText)
        elif building != 0 and floor is None:
            x = building
            flag = 0
            building = 0
            floor = 0
            room = 0
            return return_report(x,None, None, a, userText)
        elif building != 0  and floor != 0 and room is None:
            x,y = building,room
            flag = 0
            building = 0
            floor = 0
            room = 0
            return return_report(x, y, None, a, userText)
        else:
            return error
    elif flag == 2:
        return return_electric_useage(a,userText)
    else:
        print("99999999")
        return error
########################################################################################################################
def return_electric_useage(a,userText):
    if a == "today":
        dt = date.today()
        midnight = datetime.combine(dt, datetime.min.time()).timestamp()
        end_of_day = datetime.combine(dt, datetime.max.time()).timestamp()
        return jsonify({"action": "Electric_Consumption","from": str(midnight), "to": str(end_of_day)})
    elif a == "now":
        ts = time.time()
        return jsonify({"action": "Electric_Consumption","from": str(ts), "to": str(ts)})
    elif a == "yesterday":
        dt = date.today() - timedelta(days=1)
        midnight = datetime.combine(dt, datetime.min.time()).timestamp()
        end_of_day = datetime.combine(dt, datetime.max.time()).timestamp()
        return jsonify({"action": "Electric_Consumption","from": str(midnight), "to": str(end_of_day)})
    elif a == "time":
        c = datetime.strptime(str(userText), '%d/%m/%Y')
        midnight = datetime.combine(c, datetime.min.time()).timestamp()
        end_of_day = datetime.combine(c, datetime.max.time()).timestamp()
        return jsonify({"action": "Electric_Consumption","from": str(midnight), "to": str(end_of_day)})

def return_report(building, floor, room, a,userText):
    if a == "today":
        dt = date.today()
        midnight = datetime.combine(dt, datetime.min.time()).timestamp()
        end_of_day = datetime.combine(dt, datetime.max.time()).timestamp()
        return jsonify(
            {"action": "report_detail", "building": building, "floor": floor, "room": room, "from": str(midnight),
             "to": str(end_of_day)})
    elif a == "now":
        ts = time.time()
        return jsonify(
            {"action": "report_detail", "building": building, "floor": floor, "room": room, "from": str(ts),
             "to": str(ts)})
    elif a == "yesterday":
        dt = date.today() - timedelta(days=1)
        midnight = datetime.combine(dt, datetime.min.time()).timestamp()
        end_of_day = datetime.combine(dt, datetime.max.time()).timestamp()
        return jsonify(
            {"action": "report_detail", "building": building, "floor": floor, "room": room, "from": str(midnight),
             "to": str(end_of_day)})
    elif a == "time":
        c = datetime.strptime(str(userText), '%d/%m/%Y')
        midnight = datetime.combine(c, datetime.min.time()).timestamp()
        end_of_day = datetime.combine(c, datetime.max.time()).timestamp()
        return jsonify(
            {"action": "report_detail", "building": building, "floor": floor, "room": room,
             "from": str(midnight), "to": str(end_of_day)})
def text_filer(a,b):
    for x in b:
        if x in a:
            return x
    return False

if __name__ == "__main__":
    app.run(debug=True)
