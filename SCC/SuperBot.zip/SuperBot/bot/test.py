a=["1","2","3","4","5","6","7","8","9","10"]
b="tầng 4"
for x in a:
    if x in b:
        print(x)