
import pandas as pd
from svm  import SVMModel


class TextClassificationPredict(object):
    def __init__(self):
        self.test = None

    def get_train_data(self,a):
        #  train data
        train_data = []
        train_data.append({"feature": u"Hôm nay trời đẹp không ?", "target": "hoi_thoi_tiet"})
        train_data.append({"feature": u"Hôm nay thời tiết thế nào ?", "target": "hoi_thoi_tiet"})
        train_data.append({"feature": u"Hôm nay mưa không ?", "target": "hoi_thoi_tiet"})
        train_data.append({"feature": u"Hôm nay nắng không ?", "target": "hoi_thoi_tiet"})
        train_data.append({"feature": u"Hôm nay trời có mưa không ?", "target": "hoi_thoi_tiet"})
        train_data.append({"feature": u"Hôm nay trời có nắng không ?", "target": "hoi_thoi_tiet"})
        train_data.append({"feature": u"Thời tiết hôm nay?", "target": "hoi_thoi_tiet"})
        train_data.append({"feature": u"Thời tiết như thế nào?", "target": "hoi_thoi_tiet"})
        train_data.append({"feature": u"Thời tiết", "target": "hoi_thoi_tiet"})
        ################################################################################################################
        train_data.append({"feature": u"mở profile", "target": "profile"})
        train_data.append({"feature": u"coi profile", "target": "profile"})
        train_data.append({"feature": u"vào profile", "target": "profile"})
        train_data.append({"feature": u"tôi muốn mở profile", "target": "profile"})
        train_data.append({"feature": u"profile", "target": "profile"})
        train_data.append({"feature": u"mở thông tin của tôi", "target": "profile"})
        train_data.append({"feature": u"coi thông tin của tôi", "target": "profile"})
        train_data.append({"feature": u"vào thông tin của tôi", "target": "profile"})
        ################################################################################################################
        train_data.append({"feature": u"mở dashboard?", "target": "dashboard"})
        train_data.append({"feature": u"coi dashboard", "target": "dashboard"})
        train_data.append({"feature": u"vào dashboard", "target": "dashboard"})
        train_data.append({"feature": u"tôi muốn mở dashboard", "target": "dashboard"})
        train_data.append({"feature": u"dashboard", "target": "dashboard"})
        train_data.append({"feature": u"mở trang chủ ", "target": "dashboard"})
        train_data.append({"feature": u"về trang chủ", "target": "dashboard"})
        train_data.append({"feature": u"vào trang chủ", "target": "dashboard"})
        ################################################################################################################
        train_data.append({"feature": u"mở settings", "target": "settings"})
        train_data.append({"feature": u"coi settings", "target": "settings"})
        train_data.append({"feature": u"vào settings", "target": "settings"})
        train_data.append({"feature": u"tôi muốn mở settings", "target": "settings"})
        train_data.append({"feature": u"settings", "target": "settings"})
        train_data.append({"feature": u"mở cài đặt", "target": "settings"})
        train_data.append({"feature": u"về cài đặt", "target": "settings"})
        train_data.append({"feature": u"vào cài đặt", "target": "settings"})
        ################################################################################################################
        train_data.append({"feature": u"mở user list", "target": "user_list"})
        train_data.append({"feature": u"mở danh sách người dùng", "target": "user_list"})
        train_data.append({"feature": u"coi danh sách người dùng", "target": "user_list"})
        train_data.append({"feature": u"vào danh sách người dùng", "target": "user_list"})
        train_data.append({"feature": u"tôi muốn xem danh sách người dùng", "target": "user_list"})
        ################################################################################################################
        train_data.append({"feature": u"Chào em gái", "target": "chao_hoi"})
        train_data.append({"feature": u"Chào bạn", "target": "chao_hoi"})
        train_data.append({"feature": u"Hello bạn", "target": "chao_hoi"})
        train_data.append({"feature": u"Hi", "target": "chao_hoi"})
        train_data.append({"feature": u"Xin chào", "target": "chao_hoi"})
        ################################################################################################################
        train_data.append({"feature": u"report", "target": "report"})
        train_data.append({"feature": u"báo cáo", "target": "report"})
        train_data.append({"feature": u"mở báo cáo", "target": "report"})
        train_data.append({"feature": u"coi báo cáo", "target": "report"})
        train_data.append({"feature": u"xem báo cáo", "target": "report"})
        ################################################################################################################
        train_data.append({"feature": u"tạm biệt", "target": "bye"})
        train_data.append({"feature": u"goodbye", "target": "bye"})
        train_data.append({"feature": u"bye", "target": "bye"})
        train_data.append({"feature": u"bye bot", "target": "bye"})
        ################################################################################################################
        train_data.append({"feature": u"B4", "target": "building"})
        train_data.append({"feature": u"A4", "target": "building"})
        train_data.append({"feature": u"C4", "target": "building"})
        train_data.append({"feature": u"B1", "target": "building"})
        train_data.append({"feature": u"tòa B4", "target": "building"})
        train_data.append({"feature": u"tòa A4", "target": "building"})
        train_data.append({"feature": u"tòa C4", "target": "building"})
        train_data.append({"feature": u"tòa B1", "target": "building"})
        train_data.append({"feature": u"building B4", "target": "building"})
        train_data.append({"feature": u"building A4", "target": "building"})
        train_data.append({"feature": u"building C4", "target": "building"})
        train_data.append({"feature": u"building B1", "target": "building"})
        ################################################################################################################
        train_data.append({"feature": u"tất cả", "target": "report_all"})
        ################################################################################################################
        train_data.append({"feature": u"tầng", "target": "floor"})
        train_data.append({"feature": u"tầng 1", "target": "floor"})
        train_data.append({"feature": u"tầng 2", "target": "floor"})
        train_data.append({"feature": u"tầng 3", "target": "floor"})
        train_data.append({"feature": u"tầng 4", "target": "floor"})
        train_data.append({"feature": u"tầng 5", "target": "floor"})
        train_data.append({"feature": u"tầng 6", "target": "floor"})
        train_data.append({"feature": u"tầng 7", "target": "floor"})
        train_data.append({"feature": u"tầng 8", "target": "floor"})
        train_data.append({"feature": u"tầng 9", "target": "floor"})
        train_data.append({"feature": u"tầng 10", "target": "floor"})
        train_data.append({"feature": u"1", "target": "floor"})
        train_data.append({"feature": u"2", "target": "floor"})
        train_data.append({"feature": u"3", "target": "floor"})
        train_data.append({"feature": u"4", "target": "floor"})
        train_data.append({"feature": u"5", "target": "floor"})
        train_data.append({"feature": u"6", "target": "floor"})
        train_data.append({"feature": u"7", "target": "floor"})
        train_data.append({"feature": u"8", "target": "floor"})
        train_data.append({"feature": u"9", "target": "floor"})
        train_data.append({"feature": u"10", "target": "floor"})
        train_data.append({"feature": u"floor 1", "target": "floor"})
        train_data.append({"feature": u"floor 2", "target": "floor"})
        train_data.append({"feature": u"floor 3", "target": "floor"})
        train_data.append({"feature": u"floor 4", "target": "floor"})
        train_data.append({"feature": u"floor 5", "target": "floor"})
        train_data.append({"feature": u"floor 6", "target": "floor"})
        train_data.append({"feature": u"floor 7", "target": "floor"})
        train_data.append({"feature": u"floor 8", "target": "floor"})
        train_data.append({"feature": u"floor 9", "target": "floor"})
        train_data.append({"feature": u"floor 10", "target": "floor"})
        ################################################################################################################
        train_data.append({"feature": u"101", "target": "room"})
        train_data.append({"feature": u"102", "target": "room"})
        train_data.append({"feature": u"103", "target": "room"})
        train_data.append({"feature": u"104", "target": "room"})
        train_data.append({"feature": u"105", "target": "room"})
        train_data.append({"feature": u"106", "target": "room"})
        train_data.append({"feature": u"107", "target": "room"})
        train_data.append({"feature": u"108", "target": "room"})
        train_data.append({"feature": u"109", "target": "room"})
        train_data.append({"feature": u"room", "target": "room"})
        train_data.append({"feature": u"phòng", "target": "room"})
        ################################################################################################################
        train_data.append({"feature": u"cả tòa", "target": "report_all_floor"})
        train_data.append({"feature": u"cả tầng", "target": "report_all_room"})
        ################################################################################################################
        train_data.append({"feature": u"kW", "target": "kw"})
        train_data.append({"feature": u"Xem tiêu thụ điện", "target": "kw"})
        train_data.append({"feature": u"điện", "target": "kw"})
        train_data.append({"feature": u"hóa đơn tiền điện", "target": "kw"})
        train_data.append({"feature": u"kW", "target": "kw"})
        train_data.append({"feature": u"mở tiêu thụ điện", "target": "kw"})
        train_data.append({"feature": u"điện đã sử dụng", "target": "kw"})
        ###############################################################
        train_data.append({"feature": u"/", "target": "time"})
        ###############################################################
        train_data.append({"feature": u"hiện tại", "target": "now"})
        train_data.append({"feature": u"hôm nay", "target": "today"})
        train_data.append({"feature": u"hôm qua", "target": "yesterday"})
        train_data.append({"feature": u"hôm kia", "target": "today"})
        df_train = pd.DataFrame(train_data)

        #  test data
        test_data = []
        test_data.append(a)
        df_test = pd.DataFrame(test_data)
        print(df_test)
        # init model naive bayes
        model = SVMModel()
        clf = model.clf.fit(df_train["feature"], df_train.target)
        predicted = clf.predict(df_test["feature"])
        print(predicted)
        # Print predicted result
        return predicted[0]





